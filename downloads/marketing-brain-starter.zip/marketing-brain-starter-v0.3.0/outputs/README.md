# Outputs

Save finished briefs, messaging, content, and launch assets here. Include a short source list in every deliverable so another person can verify the work.
