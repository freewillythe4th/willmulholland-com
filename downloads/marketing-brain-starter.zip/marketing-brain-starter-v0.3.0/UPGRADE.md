# Upgrade to the complete system

The cohort edition can import the company and customer context you build here without overwriting completed cohort files.

1. Make a backup of this Starter folder.
2. Copy the complete Marketing Brain to a new private folder.
3. From the complete folder, run:

```bash
python3 setup/upgrade_from_starter.py /path/to/your/starter --dry-run
python3 setup/upgrade_from_starter.py /path/to/your/starter
python3 setup/install.py
```

4. Complete systems context and review permissions.
5. Rebuild the index and test one supported and one unsupported recall.

The migration preserves complete destination files and never copies credentials or generated state.
