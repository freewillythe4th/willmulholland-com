# Setup prompt

Set up this Marketing Brain Starter for me.

First read `AGENTS.md`, `START-HERE.md`, and every template under `context/`. Do not invent facts and do not inspect files outside this folder.

Then interview me in short batches to collect:

1. who I am and my role
2. company, category, stage, and current goals
3. offers, pricing, use cases, and differentiation
4. ideal customers, their situations, desired outcomes, pains, objections, and buying triggers
5. positioning, approved language, banned language, and voice
6. verified proof, metrics, customer quotes, and their sources

Write my answers into the correct files. Mark unsupported statements as assumptions or unknowns. Preserve the template headings. Do not place secrets, credentials, private personal information, or unauthorised company data in the brain.

When onboarding is complete:

- summarise what is known, assumed, and missing
- confirm which files you changed
- ask me to add one customer call or research file to `inbox/`
- explain that marketing methods come from the subscribed Intelligent Growth Skills MCP
- if I have access, help me connect it without saving credentials or method content in this folder, then call `ig_skills_list`
- run the health checklist in `AGENTS.md`
