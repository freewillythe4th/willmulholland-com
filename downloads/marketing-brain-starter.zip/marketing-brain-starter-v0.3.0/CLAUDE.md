Read and follow `AGENTS.md`. It is the shared source of operating instructions for this Marketing Brain.
