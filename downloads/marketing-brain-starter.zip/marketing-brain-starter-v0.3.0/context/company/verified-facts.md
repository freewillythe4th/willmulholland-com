# Verified facts

Only reviewed, source-backed claims belong here.

| Claim | Source | Verified date | Approved uses | Owner |
|---|---|---|---|---|
| [Add claim] | [File or URL] | YYYY-MM-DD | [Where it can be used] | [Name] |

## Targets and estimates

Targets and estimates must never be presented as achieved results.

| Statement | Type | Basis | Owner |
|---|---|---|---|
| [Add statement] | target or estimate | [Basis] | [Name] |
