# Voice

## How we should sound

- [Add trait and explain what it means]

## How we should not sound

- [Add anti-trait]

## Approved phrases

- [Add phrase]

## Avoided phrases

- [Add phrase]

## Reviewed examples

- Source:
  - Why it sounds right:
