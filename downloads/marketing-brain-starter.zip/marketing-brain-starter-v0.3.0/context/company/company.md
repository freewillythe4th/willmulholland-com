# Company

Status: template

## What the company does

[Complete during onboarding]

## Category and stage

[Complete during onboarding]

## Current business goals

[Complete during onboarding]

## Strategy and priorities

[Complete during onboarding]

## Constraints

[Complete during onboarding]

## Sources

- [Add source]
