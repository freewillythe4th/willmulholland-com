# Positioning

## Target customer

[Complete during onboarding]

## Market frame

[Complete during onboarding]

## Alternative or status quo

[Complete during onboarding]

## Differentiated value

[Complete during onboarding]

## Positioning statement

[Draft, then review]

## Assumptions to validate

- [Add assumption]
