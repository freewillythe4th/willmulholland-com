# Offers

## Products and services

- Name:
  - Buyer:
  - Problem:
  - Outcome:
  - Key use cases:
  - Pricing or packaging:
  - Evidence:
  - Source:

## What is not offered

[Complete during onboarding]
