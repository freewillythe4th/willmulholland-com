# Audiences

## Primary audience

- Role or identity:
- Company situation:
- Trigger situation:
- Job to be done:
- Desired outcome:
- Current alternatives:
- Constraints:
- Evidence sources:

## Secondary audiences

[Add only when evidence supports a distinct audience]
