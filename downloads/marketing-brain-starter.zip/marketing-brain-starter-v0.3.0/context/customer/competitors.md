# Competitors and alternatives

Include doing nothing, spreadsheets, agencies, internal workarounds, and adjacent tools when customers treat them as alternatives.

| Alternative | Why customers choose it | Strength | Weakness | Evidence |
|---|---|---|---|---|
| [Name] | [Reason] | [Strength] | [Weakness] | [Source] |
