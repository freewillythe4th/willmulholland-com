# Voice of customer

Capture exact customer language with provenance. Do not rewrite a quote and still label it verbatim.

| Theme | Exact language | Speaker context | Source | Date |
|---|---|---|---|---|
| [Pain, outcome, objection, trigger, alternative] | [Quote] | [Role and situation] | [File] | YYYY-MM-DD |

## Synthesised patterns

Each pattern must point back to evidence above.

- Pattern:
  - Evidence:
  - Confidence:
