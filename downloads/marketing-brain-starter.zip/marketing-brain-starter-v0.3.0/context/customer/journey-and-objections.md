# Journey and objections

## Trigger

[What changes and creates urgency]

## Evaluation

[Questions, criteria, stakeholders, and alternatives]

## Decision

[What creates confidence or blocks action]

## Adoption and value

[What the customer must achieve after choosing]

## Objections

| Objection in customer language | Underlying concern | Evidence | Response proof needed |
|---|---|---|---|
| [Add objection] | [Concern] | [Source] | [Proof] |
