# Start here

## Fast setup

1. Make a private copy of this folder.
2. Open the copied folder in Claude Code or Codex.
3. Paste the contents of `SETUP-PROMPT.md` into the agent.
4. Answer the onboarding questions. Say `unknown` when you do not know something.
5. Add one authorised customer call, interview, survey export, or notes file to `inbox/`.
6. Ask the agent to classify what is sourced, assumed, and missing without applying a proprietary marketing method.

## Your context model

Company context explains what the business is trying to do, what it sells, what it believes, and what it can prove.

Customer context explains who experiences the problem, what they are trying to achieve, how they describe it, and why they hesitate.

The complete system adds systems context, which explains what tools, data, permissions, and delivery routes are available.

## Marketing methods

Marketing Brain Starter contains infrastructure and context templates. It does not bundle Intelligent Growth marketing methods.

Subscribers access those methods through Intelligent Growth Skills at `https://mcp.intelligentgrowth.app/mcp`. Store the credential in your coding agent or operating system, never in this folder. After connecting, call `ig_skills_list`.

## Ground rules

- Never paste credentials or API keys into context files.
- Do not add employer or customer data unless you are authorised to use it.
- Label assumptions. Do not turn guesses into verified facts.
- Keep source links or filenames beside important claims.
- Review agent-generated context before treating it as true.
