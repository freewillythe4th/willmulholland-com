# Marketing Brain Starter by Intelligent Growth

Build a useful marketing context system in one folder. You keep the files and can use them with Claude Code, Codex, or another coding agent that reads repository instructions.

Start with `START-HERE.md`. If you already have a coding agent installed, open this folder and paste the contents of `SETUP-PROMPT.md`.

## What you will leave with

- a company context the agent can use instead of guessing
- a customer context grounded in customer language
- a verified-facts file that prevents invented claims
- an inbox for raw calls and research
- a structure where you can add methods you own

The complete Marketing Brain adds systems context, semantic search, cited memory, routing, tasks, lifecycle hooks, diagnostics, and automated maintenance. Intelligent Growth marketing methods are available separately through the subscribed Intelligent Growth Skills MCP.
