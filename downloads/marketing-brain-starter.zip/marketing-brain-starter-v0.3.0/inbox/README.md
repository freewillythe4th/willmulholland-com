# Inbox

Place authorised raw inputs here, such as interview transcripts, survey exports, sales-call notes, competitor notes, and support themes.

Do not add credentials, private keys, payment data, health data, or material you do not have permission to use.
