# Skills

Marketing Brain Starter does not bundle Intelligent Growth marketing methods. Connect the Intelligent Growth Skills MCP to access subscribed methods, or add methods you create and own here.
